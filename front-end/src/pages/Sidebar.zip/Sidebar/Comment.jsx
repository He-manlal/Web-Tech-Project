import React from 'react';
import SideBar from './SideBar'

const Comment = () => {
    return (
        <div>                    <SideBar/>

            <h1>Comment page</h1>
        </div>
    );
};

export default Comment;