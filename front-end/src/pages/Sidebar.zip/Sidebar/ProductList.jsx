import React from 'react';
import SideBar from './SideBar'

const ProductList = () => {
    return (
        <div>                    <SideBar/>

            <h1>product list page</h1>
        </div>
    );
};

export default ProductList;