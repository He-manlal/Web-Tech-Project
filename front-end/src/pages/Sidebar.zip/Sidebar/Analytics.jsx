import React from 'react';
import SideBar from './SideBar'
const Analytics = () => {
    return (
        <div>
                    <SideBar/>

            <h1>Analytics page</h1>
        </div>
    );
};

export default Analytics;