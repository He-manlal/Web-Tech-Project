import React from 'react';
import SideBar from './SideBar'

const About = () => {
    return (
        <div>                    <SideBar/>

            <h1>About page</h1>
        </div>
    );
};

export default About;