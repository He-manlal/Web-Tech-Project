import React from 'react';
import SideBar from './SideBar'

const Dashboard = () => {
    return (
        <div>                    <SideBar/>

            <h1>dashboard page</h1>
        </div>
    );
};

export default Dashboard;